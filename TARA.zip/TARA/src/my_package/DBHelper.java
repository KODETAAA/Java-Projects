/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package my_package;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Psalm XXIII V. Alonzo
 * version 1.0
 * @date 3/10/2021
 */
public class DBHelper {
    Connection con = null;
    Statement st = null;
    public void connectDB() throws Exception{
        con = DriverManager.getConnection("jdbc:derby://localhost:1527/dbCreate", "alonzo", "alonzo");
        System.out.println("Connected to Database!");
    }
    
    public boolean insertRecord(String fname, String uname, String pass, String gen, int id){
       boolean flag = false;
        
        try {
            st = con.createStatement();
            String sql = "Insert into tblRegister values ('"+fname+"','"+uname+"','"+pass+"','"+gen+"',"+id+")";
            if(st.executeUpdate(sql) == 1)
                flag = true;
        } catch (SQLException ex) {
            Logger.getLogger(DBHelper.class.getName()).log(Level.SEVERE, null, ex);
        }
            return flag;
        }
       

}
