/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package my_package;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Psalm XXIII V. Alonzo
 * version 1.0
 * @date 3/10/2021
 */
public class DBHelper {
    Connection con = null;
    Statement st = null;
    public void connectDB() throws Exception{
        con = DriverManager.getConnection("jdbc:derby://localhost:1527/dbCreate", "alonzo", "alonzo");
        System.out.println("Connected to Database!");
    }
    
    public boolean insertRecord(String fname, String uname, String pass, String gen, int id){
       boolean flag = false;
        
        try {
            st = con.createStatement();
            String sql = "Insert into tblRegister values ('"+fname+"','"+uname+"','"+pass+"','"+gen+"',"+id+")";
            if(st.executeUpdate(sql) == 1)
                flag = true;
        } catch (SQLException ex) {
            Logger.getLogger(DBHelper.class.getName()).log(Level.SEVERE, null, ex);
        }
            return flag;
        }
    
     public boolean insertRecordResevation(String des, String date, String time, int vec){
       boolean flag = false;
        
        try {
            st = con.createStatement();
            String sql = "Insert into tblReservationRecord values ('"+des+"','"+date+"','"+time+"',"+vec+")";
            if(st.executeUpdate(sql) == 1)
                flag = true;
        } catch (SQLException ex) {
            Logger.getLogger(DBHelper.class.getName()).log(Level.SEVERE, null, ex);
        }
            return flag;
        }
    
    public ResultSet displayAllRecord(){
       ResultSet rss = null;
        try {
            st = con.createStatement();
            String sql = "Select * from tblReservationRecord";
             rss = st.executeQuery(sql);
        } catch (SQLException ex) {
            Logger.getLogger(DBHelper.class.getName()).log(Level.SEVERE, null, ex);
        }
        return rss;
    }
    
     public ResultSet displayByDestination(String des){
       ResultSet rss = null;
        try {
            
            st = con.createStatement();
             
            String sql = "Select * from tblReservationRecord where destination = '"+des+"'";
             rss = st.executeQuery(sql);
        } catch (SQLException ex) {
            Logger.getLogger(DBHelper.class.getName()).log(Level.SEVERE, null, ex);
        }
        return rss;
    }
     
     /*public ResultSet deleteRecord(String dest){
       ResultSet rss = null;
        try {
            st = con.createStatement();
            
            String sql = "Delete * from tblReservationRecord where Date = '"+dest+"'";
             rss = st.executeQuery(sql);
        } catch (SQLException ex) {
            Logger.getLogger(DBHelper.class.getName()).log(Level.SEVERE, null, ex);
        }
        return rss;
    }*/
    
    
       
    public void disconnectDB(){
        if(con != null)
            try {
                con.close();
                System.out.println("Disconnected");
        } catch (SQLException ex) {
            Logger.getLogger(DBHelper.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
