/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.myjavaapplication;

/**
 *
 * @author Psalm XXIII V. Alonzo
 * @version 1.0
 * Date February 19, 2021
 */
public class myfirstjavaapplication {
    
    public static void main(String[] args) {
       
    }
}
