
import javax.swing.JFrame;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author user
 */
public class Product extends JFrame {
    private int code;
    private String name;
    double cost;
    int stock;
    
    public Product(){
    }
    public Product(int code, String name, double cost, int stock){
        this.code = code;
        this.name = name;
        this.cost = cost;
        this.stock = stock;
    }

    public int getCode() {
        return code;
    }

    public String getName() {
        return name;
    }

    public double getCost() {
        return cost;
    }

    public int getStock() {
        return stock;
    }
    
    public boolean sell(int count){
    if(count < getStock()){
        count = getStock();
       System.out.println(count);
       return true;
    }else{
        System.out.println("Insufficient Stock!");
    }
    return false;
    }
    
    public void purchase(int count){
        int b;
        if(count <= getStock()){
            count = count - getStock();
            System.out.println(count);
     }else{
            System.out.println("Insufficient Stocks! Try Again!");
            
        }
    }
    
    public void priceIncrease(float rate){
        
    }
    
    public void Display(){
       
        
    }
}